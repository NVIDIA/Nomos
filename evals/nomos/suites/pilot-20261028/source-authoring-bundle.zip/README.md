# Private Nomos evaluation authoring bundle

Review this private artifact before sharing. Automated redaction is bounded and
cannot establish that arbitrary natural-language content is safe to publish.
`manifest.json` inventories exported bytes; `evidence/records.jsonl` is transformed
ledger content, NOT an original signed payload. Source hashes identify originals;
export hashes describe different bytes. Original signatures/capabilities are absent.

Start with `completeness.json`: each selected finding is a separate candidate.
Missing historical records are never replaced by recent unrelated activity.
Council approval is not execution success; receipt output hashes are not output.
Historical ETHOS files retain original source hashes and mapping provenance;
redacted documents are explicitly transformed and require semantic review.
No root ETHOS or generic tool catalog is invented. Shared source records are deduplicated.

## Offline toolchain and supported routes

Tested Eval Author revision: 20f95a0a010d4905c13065678af51970404910c9.
The deployment includes only deterministic validation scripts, not an authoring
agent, Harbor, Docker task images, or model credentials.

Council-only captures use Eval Author's repository-based `eval-author-first-eval`
workflow. They are NOT native ATIF and must not be placed in a trace input directory.
Open a private recipient repository with Eval Author at the pinned revision, give
it this extracted bundle as the explicit evidence corpus, and ask:

> Use Eval Author to build one private Harbor evaluation case for the selected
> council decision finding. Read completeness.json, findings.json, runs.json,
> evidence/ and the applicable historical ethos/ documents. Preserve the distinction
> between recorded evidence and proposed fixture inputs. Record missing contract,
> policy, council code/model configuration and environment prerequisites before
> scaffolding. Follow eval-author-first-eval; do not invent the original user goal.

Only files listed under `validation.json.traces` passed the pinned ATIF preparation
command. For such a file, use the upstream trace-to-environment workflow:

> Use Eval Author to derive a private Harbor task from /absolute/path/traces/FILE.atif.json.
> Review privacy, ground truth and conversion losses, then validate the candidate
> when its required runtime is available.

You supply your agent repository/runtime, applicable contract if absent, tool
schemas if absent, model access and any initial world state Nomos never recorded.
Do not treat council explanations as client dialogue. Do not infer commands or
results from digests. Review redactions and supply missing inputs privately with
explicit external provenance; a supplement is not historical ledger evidence.

Review the authored instruction and verifier against the applicable contract.
Run Harbor oracle, nop and a realistic targeted incorrect control. Verify reward
1 for the correct solution and 0 for both failure controls, with no runtime errors.
Task proof and trace preparation are separate from measured agent performance.
Then run the real agent with your configured provider; retain execution traces,
receipts and task hashes before comparing a baseline and candidate.

The reproducible council/manual pilot, exact offline commands, runtime pin and
proof limitations are in Nomos docs/assurance/EVALUATION.md. Export does not run
an optimizer, change permissions, or establish production evaluation coverage.
